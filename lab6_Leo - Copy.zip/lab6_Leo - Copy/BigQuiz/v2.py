import pgzrun
import random

WIDTH = 800
HEIGHT = 600

# Define colors
WHITE = (255, 255, 255)
BLUE = (50, 120, 230)

# Define the quiz questions and answers
questions = [
    {
        "question": "What is the capital of France?",
        "answers": ["Paris", "Rome", "Berlin", "Madrid"],
        "correct": "Paris",
        "hint": "It's known as the 'City of Love'."
    },
    {
        "question": "Which planet is known as the Red Planet?",
        "answers": ["Venus", "Mars", "Jupiter", "Saturn"],
        "correct": "Mars",
        "hint": "It's named after the Roman god of war."
    },
    {
        "question": "What is the largest mammal in the world?",
        "answers": ["Elephant", "Giraffe", "Blue Whale", "Hippopotamus"],
        "correct": "Blue Whale",
        "hint": "It's a marine mammal."
    },
    # Add more questions here
    {
        "question": "What is the largest ocean in the world?",
        "answers": ["Pacific Ocean", "Atlantic Ocean", "Indian Ocean", "Arctic Ocean"],
        "correct": "Pacific Ocean",
        "hint": "It's the deepest and largest ocean."
    },
    {
        "question": "Who painted the Mona Lisa?",
        "answers": ["Vincent van Gogh", "Leonardo da Vinci", "Pablo Picasso", "Michelangelo"],
        "correct": "Leonardo da Vinci",
        "hint": "He was a famous Italian polymath."
    }
]

current_question = 0
score = 0
show_hint = False  # Flag to determine if the hint should be shown
background = "bk.png"

def draw():
    screen.fill(BLUE)

    try:
        background_image = Actor(background)
        background_image.pos = (WIDTH // 2, HEIGHT // 2)
        background_image.draw()

        screen.draw.text(questions[current_question]["question"], center=(WIDTH / 2, 100), color=WHITE, fontsize=30)
        
        y = 200
        for answer in questions[current_question]["answers"]:
            screen.draw.text(answer, center=(WIDTH / 2, y), color=WHITE, fontsize=25)
            y += 100

        screen.draw.text("Score: " + str(score), (50, 550), color=WHITE, fontsize=30)
        screen.draw.text("Press 'H' for Hint", (50, 580), color=WHITE, fontsize=20)

        # Display the hint if show_hint is True
        if show_hint:
            hint = "Hint: " + questions[current_question]["hint"]
            screen.draw.text(hint, center=(WIDTH / 2, 550), color=WHITE, fontsize=20)

    except Exception as e:
        print(f"Error drawing the interface: {e}")

def on_key_down(key):
    global show_hint
    if key == keys.H:
        # Toggle the show_hint flag to display the hint
        show_hint = not show_hint
        
def on_mouse_down(pos):
    global current_question, score
    index = (pos[1] - 150) // 100

    if 0 <= index < len(questions[current_question]["answers"]):
        if questions[current_question]["answers"][index] == questions[current_question]["correct"]:
            score += 5  # Increased points for a correct answer
            
        current_question = random.randint(0, len(questions) - 1)


pgzrun.go()
