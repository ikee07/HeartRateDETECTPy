import pgzrun
import random

WIDTH = 800
HEIGHT = 600

# Define colors
WHITE = (255, 255, 255)
LIGHT_BLUE = (255, 255, 255)
DARK_BLUE = (65, 105, 225)
SHADE = (30, 30, 30, 100)
# Define the quiz questions and answers
questions = [
    {
        "question": "What is the capital of France?",
        "answers": ["Paris", "Rome", "Berlin", "Madrid"],
        "correct": "Paris",
        "hint": "It's known as the 'City of Love'."
    },
    {
        "question": "Which planet is known as the Red Planet?",
        "answers": ["Venus", "Mars", "Jupiter", "Saturn"],
        "correct": "Mars",
        "hint": "It's named after the Roman god of war."
    },
    {
        "question": "What is the largest mammal in the world?",
        "answers": ["Elephant", "Giraffe", "Blue Whale", "Hippopotamus"],
        "correct": "Blue Whale",
        "hint": "It's a marine mammal."
    },
    {
        "question": "What is the largest ocean in the world?",
        "answers": ["Pacific Ocean", "Atlantic Ocean", "Indian Ocean", "Arctic Ocean"],
        "correct": "Pacific Ocean",
        "hint": "It's the deepest and largest ocean."
    },
    {
        "question": "Who painted the Mona Lisa?",
        "answers": ["Vincent van Gogh", "Leonardo da Vinci", "Pablo Picasso", "Michelangelo"],
        "correct": "Leonardo da Vinci",
        "hint": "He was a famous Italian polymath."
    },
    # Additional questions
    {
        "question": "Which gas do plants absorb that humans exhale?",
        "answers": ["Oxygen", "Carbon Dioxide", "Nitrogen", "Methane"],
        "correct": "Carbon Dioxide",
        "hint": "It's necessary for photosynthesis."
    },
    {
        "question": "What is the largest organ in the human body?",
        "answers": ["Liver", "Skin", "Heart", "Lungs"],
        "correct": "Skin",
        "hint": "It's your body's outer covering."
    },
    {
        "question": "Who is credited with the invention of the telephone?",
        "answers": ["Thomas Edison", "Alexander Graham Bell", "Nikola Tesla", "Albert Einstein"],
        "correct": "Alexander Graham Bell",
        "hint": "He's an inventor and scientist."
    }
]

current_question = 0
score = 0
show_hint = False
background = Actor("button.png", (WIDTH / 2, HEIGHT / 2))

# Calculate answer button positions
answer_positions = [(WIDTH // 2, 200), (WIDTH // 2, 300), (WIDTH // 2, 400), (WIDTH // 2, 500)]

# Variable to keep track of which answer is being hovered over
hovered_answer = None

def draw():
    screen.clear()
    background.draw()

    try:
        screen.draw.text(questions[current_question]["question"], center=(WIDTH / 2, 100), color=WHITE, fontsize=30)

        # Draw answer buttons with boxes and shading for faux 3D effect
        for i, answer in enumerate(questions[current_question]["answers"]):
            box_rect = Rect((WIDTH // 2 - 120, 170 + i * 100), (240, 40))
            shaded_rect = Rect(box_rect.topleft, (box_rect.width, box_rect.height // 2))
            screen.draw.filled_rect(box_rect, DARK_BLUE)
            screen.draw.filled_rect(shaded_rect, SHADE)
            screen.draw.text(answer, center=answer_positions[i], color=WHITE, fontsize=25)

        screen.draw.text("Score: " + str(score), (50, 550), color=WHITE, fontsize=30)
        screen.draw.text("Press 'H' for Hint", (50, 580), color=WHITE, fontsize=20)

        # Display the hint if show_hint is True
        if show_hint:
            hint = "Hint: " + questions[current_question]["hint"]
            screen.draw.text(hint, center=(WIDTH / 2, 550), color=WHITE, fontsize=20)

    except Exception as e:
        print(f"Error drawing the interface: {e}")

def on_mouse_move(pos):
    global hovered_answer
    for i, pos_answer in enumerate(answer_positions):
        if abs(pos[0] - pos_answer[0]) < 120 and abs(pos[1] - pos_answer[1]) < 20:
            hovered_answer = i
            return
    hovered_answer = None

def on_mouse_down(pos):
    global score, current_question
    for i, pos_answer in enumerate(answer_positions):
        if abs(pos[0] - pos_answer[0]) < 100 and abs(pos[1] - pos_answer[1]) < 20:
            if questions[current_question]["answers"][i] == questions[current_question]["correct"]:
                score += 5  # Increase points for a correct answer
            current_question = random.randint(0, len(questions) - 1)

def on_key_down(key):
    global show_hint
    if key == keys.H:
        # Toggle the show_hint flag to display the hint
        show_hint = not show_hint

pgzrun.go()