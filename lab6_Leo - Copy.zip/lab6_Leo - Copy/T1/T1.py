import tensorflow as tf
from tensorflow.keras import datasets, layers, models
from tensorflow.keras.optimizers import legacy

# Load CIFAR-10 data
(train_images, train_labels), (test_images, test_labels) = datasets.cifar10.load_data()

# Normalize pixel values
train_images, test_images = train_images / 255.0, test_images / 255.0

# Define data augmentation
datagen = tf.keras.preprocessing.image.ImageDataGenerator(
    rotation_range=15,
    width_shift_range=0.1,
    height_shift_range=0.1,
    horizontal_flip=True,
    zoom_range=0.1
)
datagen.fit(train_images)

# Build a baseline CNN model
def create_model():
    model = models.Sequential()
    model.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape=(32, 32, 3)))
    model.add(layers.BatchNormalization())
    model.add(layers.Conv2D(32, (3, 3), activation='relu'))
    model.add(layers.BatchNormalization())
    model.add(layers.MaxPooling2D((2, 2)))
    model.add(layers.Dropout(0.3))

    # Additional Conv2D layers, MaxPooling, and Dropout for increased complexity
    model.add(layers.Conv2D(64, (3, 3), activation='relu'))
    model.add(layers.BatchNormalization())
    model.add(layers.Conv2D(64, (3, 3), activation='relu'))
    model.add(layers.BatchNormalization())
    model.add(layers.MaxPooling2D((2, 2)))
    model.add(layers.Dropout(0.4))

    model.add(layers.Flatten())
    model.add(layers.Dense(128, activation='relu'))
    model.add(layers.BatchNormalization())
    model.add(layers.Dropout(0.5))
    model.add(layers.Dense(10, activation='softmax'))

    return model

# Function to create and train multiple models for ensemble
def train_models(num_models, epochs):
    models = []
    for _ in range(num_models):
        model = create_model()
        model.compile(optimizer=legacy.Adam(learning_rate=0.001),
                      loss='sparse_categorical_crossentropy',
                      metrics=['accuracy'])

        model.fit(datagen.flow(train_images, train_labels, batch_size=64),
                  epochs=epochs, validation_data=(test_images, test_labels))
        models.append(model)
    return models

# Train multiple models
num_models = 2  # You can adjust the number of models
epochs = 50
ensemble_models = train_models(num_models, epochs)

# Function to predict and ensemble results
def predict_ensemble(models, test_data):
    predictions = [model.predict(test_data) for model in models]
    return tf.reduce_mean(predictions, axis=0)

# Make predictions using ensemble
ensemble_predictions = predict_ensemble(ensemble_models, test_images)
test_acc = tf.keras.metrics.SparseCategoricalAccuracy()
test_acc.update_state(test_labels, ensemble_predictions)
accuracy = test_acc.result().numpy()
print(f"Ensemble Test accuracy: {accuracy * 100:.2f}%")
